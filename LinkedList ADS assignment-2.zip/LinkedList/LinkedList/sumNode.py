from SingleLL import SingleList

def get_sum(self, n):
    if n <= 0 or self.is_empty() or n > self.size():
        return 0

    f_pointer = self.head
    b_pointer = self.head

    for _ in range(n):
        if f_pointer is None:
            return 0
        f_pointer = f_pointer.next

    while f_pointer:
        f_pointer = f_pointer.next
        b_pointer = b_pointer.next

    sum_last_n_nodes = 0
    while b_pointer:
        sum_last_n_nodes += b_pointer.data
        b_pointer = b_pointer.next

    return sum_last_n_nodes

def main():
    l1 = SingleList()
    l1.add_at_tail(10)
    l1.add_at_tail(20)
    l1.add_at_tail(30)
    l1.add_at_tail(40)
    l1.add_at_tail(50)
    print(l1.print_all_elements())
    
    n = int(input("Enter the number of last nodes to sum: "))
    if n<=l1.size():
        sum_last_n = l1.get_sum(n)
        print(f"Sum of the last {n} nodes: {sum_last_n}")
    else:
        print("list length is ",l1.size()," error!!!")

if __name__ == "__main__":
    SingleList.get_sum = get_sum
    main()

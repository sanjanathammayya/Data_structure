from SingleLL import SingleList

def split(self):
    l1 = SingleList()
    l2 = SingleList()

    current = self.head
    toggle = True

    while current:
        if toggle:
            l1.add_at_tail(current.data)
        else:
            l2.add_at_tail(current.data)
        
        toggle = not toggle
        current = current.next

    return l1, l2

SingleList.split = split

def main():
    l1 = SingleList()
    l1.add_at_tail(1)
    l1.add_at_tail(2)
    l1.add_at_head(3)
    l1.add_at_tail(4)
    l1.add_at_tail(5)
    l1.add_at_head(0)
    
    
    print("Original list:")
    current = l1.head
    while current:
        print(current.data, end="  ")
        current = current.next
    print("\n")

    l1a, l1b = l1.split()

    print("First split list:")
    current = l1a.head
    while current:
        print(current.data, end="  ")
        current = current.next
    print("\n")

    print("Second split list:")
    current = l1b.head
    while current:
        print(current.data, end="  ")
        current = current.next
    print("\n")

if __name__ == "__main__":
    main()

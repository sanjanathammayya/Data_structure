from SingleLL import SingleList

def main():
    def to_set(single_list):
        elements = set()
        cur = single_list.head
        while cur:
            elements.add(cur.data)
            cur = cur.next
        return elements

    l1 = SingleList()
    l2 = SingleList()

    l1.add_at_tail(1)
    l1.add_at_tail(2)
    l1.add_at_tail(3)
    l1.add_at_tail(4)
    
    l2.add_at_tail(3)
    l2.add_at_tail(4)
    l2.add_at_tail(5)
    l2.add_at_tail(6)
    
    elements_set_1 = to_set(l1)  
    common_list = SingleList()      

    cur = l2.head
    while cur:
        if cur.data in elements_set_1:
            common_list.add_at_tail(cur.data)
        cur = cur.next
    
    cur = l1.head
    while cur:
        print(cur.data, end="  ")
        cur = cur.next
    print("\n")

    cur = l2.head
    while cur:
        print(cur.data, end="  ")
        cur = cur.next
    print("\n")
    # cur = common_list.head
    # while cur:
    #     print(cur.data, end="  ")
    #     cur = cur.next
    # print("\n")

    print("Common elements in both lists:")
    cur = common_list.head
    while cur:
        print(cur.data)
        cur = cur.next

if __name__ == "__main__":
    main()

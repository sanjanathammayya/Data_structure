from SingleLL import SingleList

def remove_duplicates(self):
    if self.is_empty():
        return

    s = set()
    cur = self.head
    prev = None

    while cur:
        if cur.data in s:
            prev.next = cur.next
            if cur == self.tail:
                self.tail = prev
        else:
            s.add(cur.data)
            prev = cur

        cur = cur.next

def main():
    list1 = SingleList()
    list1.add_at_head(10)
    list1.add_at_tail(20)
    list1.add_at_tail(10)
    list1.add_at_tail(30)
    list1.add_at_tail(20)
    list1.add_at_head(20)
    list1.add_at_tail(40)
    
    print("Original list:")
    cur = list1.head
    while cur:
        print(cur.data, end=" ")
        cur = cur.next
    print("")

    list1.remove_duplicates()
    
    print("List after removing duplicates:")
    cur = list1.head
    while cur:
        print(cur.data, end=" ")
        cur = cur.next
    print("")

if __name__ == "__main__":
    SingleList.remove_duplicates = remove_duplicates
    main()

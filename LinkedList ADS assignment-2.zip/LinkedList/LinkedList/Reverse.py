from SingleLL import SingleList

def reverse(self):
    prev = None
    cur = self.head
    self.tail = self.head  # The old head will become the new tail

    while cur:
        next_node = cur.next  # Save the next node
        cur.next = prev  # Reverse the link
        prev = cur  # Move prev to the cur node
        cur = next_node  # Move to the next node

    self.head = prev  # Update head to the new front of the list

SingleList.reverse = reverse  

def main():
    list1 = SingleList()
    list1.add_at_tail(10)
    list1.add_at_tail(20)
    list1.add_at_tail(30)
    list1.add_at_tail(40)
    list1.add_at_tail(50)
    
    print("Original list:")
    cur = list1.head
    while cur:
        print(cur.data, end="  ")
        cur = cur.next
    print("\n")

    list1.reverse()
    
    print("Reversed list:")
    cur = list1.head
    while cur:
        print(cur.data, end="  ")
        cur = cur.next

if __name__ == "__main__":
    main()
